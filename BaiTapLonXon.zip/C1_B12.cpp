#include <iostream>
#define MAX 100
int a[MAX];
int front, rear;

void init()
{
    front = -1;
    rear = -1;
}
int push(int x)
{
    if (rear - front == MAX-1)
        return 0;
    else
    {
        if (front == -1)
            front ==0;
        if (rear == MAX -1)
        {
            for (int i = front; i < rear; i++)
            {
                a[i-front] = a[i];
            }
            rear = MAX -1 - front;
            front == 0;
        }
        a[++rear] = x;
        return 1;
    }
}
int pop(int &x)
{
    if (front == -1) // if queue is empty
        return 0;
    else
    {
        x = a[front++];
        if (front > rear)
        {
            init();
        }
        return 1;
    }
}
int isFull()
{
    if (rear - front == MAX-1)
        return 1;
    return 0;
}
int isEmpty()
{
    if (front == -1)
        return 1;
    return 0;
}
int main()
{
    init();
    return 0;
}